setwd("C:/Users/IT24100618/Desktop/IT24100618")
branch_data<-read.table("Exercise.txt",header=TRUE,sep = ",")
fix(branch_data)
attach(branch_data)

str(branch_data)
sapply(branch_data, class)

boxplot(X1,main="Box Plot for Sales",outline=TRUE,outpch=8,horizontal=TRUE)

#Summery - X2
summary(X2)
IQR(X2)

get.outliers<-function(z){
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  iqr <- q3 - q1
  
  ub <- q3 + 1.5*iqr
  lb <- q1 - 1.5*iqr
  
  print(paste("Upper Bound = ",ub))
  print(paste("Lower Bound = ",lb))
  print(paste("Outliers : ",paste(sort(z[z<lb | z>ub]),collapse = ",")))
}

get.outliers(X3)


