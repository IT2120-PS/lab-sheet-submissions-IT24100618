
setwd("C:\\Users\\it24100618\\Desktop\\IT24100618") 

student_data <- read.csv("C:/Users/it24100618/Desktop/IT24100618/Exercise (2).csv")

head(student_data)


# 2
summary(student_data$X1)
hist(student_data$X1, main = "Histogram of Age (X1)", xlab = "Age", col = "red", border = "black")

#3
gender_table <- table(student_data$X2)
print(gender_table)

barplot(gender_table, main = "Gender Distribution", col = c("green", "blue"), names.arg = c("Male", "Female"))

# 4
boxplot(X1 ~ X3, data = student_data, main = "Age by Accommodation Type", 
        xlab = "Accommodation Type", ylab = "Age", col = c("blue", "green", "red"))


